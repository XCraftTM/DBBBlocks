#1 Make backup of Discord Bot Builder\resources  
 ///usually C:\Program Files (x86)\Steam\steamapps\common\Discord Bot Builder\resources

#2 Put the content of this folder to that folder

#3 In "style.css" define @import "themes/your-theme-name.css" 
 ///default @import "themes/milky.css"

#4 If you wanna create your own theme, edit the "template.css" in ./themes folder


<1> MAKE A COPY OF TEMPLATE FILE!!!
<2> EDIT ONLY COPIED TEMPLATE.CSS FILE
<3> AFTER FULL EDIT RENAME FILE
<4> THEN CHANGE @import TO YOUR NEW THEME FILE NAME


# MASKALI's Theme Creator 2022
# for more contact мαятιη ѕкαℓι¢кý#6544
# https://modernalt.eu
# on DBB server as M&RT!N!×J
# V2.0
